<a href="login.php"class="w3-bar-item w3-button w3-padding-large w3-hide-small" >LOGIN</a>
<a href="signup.php"class="w3-bar-item w3-button w3-padding-large w3-hide-small"  >SIGNUP</a>