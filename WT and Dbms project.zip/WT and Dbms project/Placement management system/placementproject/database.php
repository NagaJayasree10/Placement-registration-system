<?php
$conn = mysqli_connect('localhost', 'root', '',"placementproject") or die("Database Connection failed.");