<html>

<head>
    <title>Placement management system</title>
    <link rel="stylesheet" href="./css/styles.css">
    
</head>

<body>
    
    <div class="header"></div>
    <input type="checkbox" class="openSidebarMenu" id="openSidebarMenu">
    <label for="openSidebarMenu" class="sidebarIconToggle">
    <div class="spinner diagonal part-1"></div>
    <div class="spinner horizontal"></div>
    <div class="spinner diagonal part-2">

    </div>
    
   
  </label>
    <div id="sidebarMenu">
        <ul class="sidebarMenuInner">
            <li>SRM University, AP<span>Placement management system</span></li>
            <li><a href="login.php" >Student login</a></li>
            <li><a href="Aboutus.php" >Get in touch</a></li>
            
    
        </ul>
    </div>
    <div class='first'>
        <h1 style="font-weight: bolder;">PLACEMENT MANAGEMENT SYSTEM</h1>
        <p style="color: black;font-size: x-large;">We are here to Build your Skills and Career with our Driven Passion and Reality.</p>
    </div>
    
    </body>

</html>